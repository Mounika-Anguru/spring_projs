package com.demo.spring;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Job job =(Job)context.getBean("job");
		JobLauncher jobLauncher =(JobLauncher)context.getBean("jobLauncher");
		
		try {
			JobParameters params= new JobParametersBuilder().addString("jobID", String.valueOf(System.currentTimeMillis())).toJobParameters();
			org.springframework.batch.core.JobExecution jobExecution=jobLauncher.run(job, params);
			System.out.println(jobExecution.getExitStatus());
			System.out.println("Job Completed...");
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(("Job Failed.."));
		}
	}

}
