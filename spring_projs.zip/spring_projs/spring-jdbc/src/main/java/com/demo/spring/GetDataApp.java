package com.demo.spring;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class GetDataApp {

	public static void main(String[] args) {
		
		String INSERT_STMT = "insert into emp(empno,name,address,salary) values(?,?,?,?)";
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		JdbcTemplate jt = (JdbcTemplate)context.getBean("jdbcTemplate");
		
	    List<Emp> empList = jt.query("select * from emp", new RowMapper<Emp>() {
	    	
	    	@Override
	    	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException{
	    		return new Emp(rs.getInt("EmpNo"),
	    				rs.getString("Name"),
	    				rs.getString("ADDRESS"),
	    				rs.getDouble("Salary"));
	    	}
	    });
	   for(Emp e:empList) {
		   System.out.println(e.getEmpId() + " "+ e.getName() + " " + e.getCity()+ " "+ e.getSalary());
	   }
 
	}

}
