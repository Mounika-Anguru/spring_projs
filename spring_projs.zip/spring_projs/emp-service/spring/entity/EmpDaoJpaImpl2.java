package com.demo.spring.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("Dao")
@Transactional
public class EmpDaoJpaImpl2 {
	@PersistenceContext
	EntityManager em;
	
	public String saveEmp(Emp e) {
		em.persist(e);
		return "Data saved in DB";
	}
	
public Emp findEmpById(int Id) {
	Emp e = em.find(Emp.class, Id);
	if(e!=null) {
		return e;
	}
	else {
		throw new RuntimeException("No Emp Found");
	}
}

public List<Emp> findAllEmp(){
	Query query = em.createNativeQuery("select e from Emp e");
	List<Emp> empList = query.getResultList();
	return empList;
	
}

}
