package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.entity.Emp;
import com.demo.spring.entity.EmpDaoJpaImpl;

public class App {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		EmpDaoJpaImpl dao = (EmpDaoJpaImpl)context.getBean("Dao");
		
		String resp = dao.saveEmp(new Emp(308, "Sraveen", "Hyd", 100000));
		System.out.println(resp);
		
		Emp empfound= dao.findEmpById(307);
		System.out.println(empfound.getEmpId()+ " "+ empfound.getName());
		
		dao.findAllEmp().stream().forEach(e -> System.out.println(e.getEmpId()+" "+ e.getName()));
	}
}
