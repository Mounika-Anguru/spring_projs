package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		//we are starting the sprint by creating container with name context
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		
		//tell spring to get me the mail bean
		
		//Mail mail = (Mail)context.getBean("mail"); (the same can be achieved as below)
		//By default the object will be sigleton and we can override the scope to prototype as required
		Mail mail = context.getBean(Mail.class);
		
      System.out.println(mail.getMessage().getBody());
	}

}
