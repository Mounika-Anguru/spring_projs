package com.demo.spring;

import com.demo.spring.entity.Emp;

public interface EmpRepository {

	void save(Emp e);

	
}
